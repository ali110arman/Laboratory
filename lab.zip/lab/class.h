#pragma once
#include <iostream>
#include <fstream>
#include<string>
using namespace std;


void setColor(int textColor, int backColor);

class lab {
protected:
	string search_name;
	string name_search;
	string lab_name;
private:
	string rezerve_name;
	int rezerve_num;
	string rezerve_kind;
	int rezerve_price;
	string rezerve_date;
	string rezerve_hour;
	string choose_day;
	string choose_hour;
public:
	void showlab();
	void findlab();
	void showexperiment();
	void choose_experiment();
	void rezerve(string);
	void add_lab();
	void add_experiment();
};


class gozaresh {
private:
public:
	void menu();
	void show_users();
	void show_money();
	void taedshode();
	void taednashode();
};



