#include <Windows.h>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void setColor(int textColor, int backColor) {
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	int colorAttribute = backColor << 4 | textColor;
	SetConsoleTextAttribute(consoleHandle, colorAttribute);
	/*	0 = Black       8 = Gray
		1 = Blue        9 = Light Blue
		2 = Green       10 = Light Green
		3 = Aqua        11 = Light Aqua
		4 = Red         12 = Light Red
		5 = Purple      13 = Light Purple
		6 = Yellow      14 = Light Yellow
		7 = White       15 = Bright White*/
}

class lab {
protected:
	string search_name;
	string name_search;
	string lab_name;
private:
	string rezerve_name;
	int rezerve_num;
	string rezerve_kind;
	int rezerve_price;
	string rezerve_date;
	string rezerve_hour;
	string choose_day;
	string choose_hour;
public:
	void showlab();
	void findlab();
	void showexperiment();
	void choose_experiment();
	void rezerve(string);
	void add_lab();
	void add_experiment();
};
class gozaresh {
private:
public:
	void menu();
	void show_users();
	void show_money();
	void taedshode();
	void taednashode();
};
void lab::showlab() {
	ifstream show("lab.txt");
	string name;
	int num;
	while (show >> num) {
		show >> name;
		cout << num << " " << name << endl;
	}
	show.close();
}
void lab::findlab() {
	int choose;
	cin >> choose;
	ifstream find("lab.txt");
	int num_search;
	while (find >> num_search) {
		find >> name_search;
		if (choose == num_search) {
			search_name = name_search + ".txt";
			lab_name = name_search;
			break;
		}
	}
}
void lab::showexperiment() {
	system("cls");
	ifstream show(search_name);
	string name;
	int num;
	string kind;
	int price;
	string date;
	string hour;
	while (show >> num) {
		show >> name;
		show >> kind;
		show >> price;
		show >> date;
		show >> hour;
		cout << num << "	" << name << "		" << kind << "		" << price << "	" << date << endl;
	}
}
void lab::choose_experiment() {
	int choose;
	cin >> choose;
	ifstream show(search_name);
	while (show >> rezerve_num) {
		show >> rezerve_name;
		show >> rezerve_kind;
		show >> rezerve_price;
		show >> rezerve_date;
		show >> rezerve_hour;
		if (choose == rezerve_num) {
			setColor(2, 15);
			cout << "tarikh entekhaby ra vared konid :";
			setColor(1, 15);
			cin >> choose_day;
			setColor(2, 15);
			cout << "rooz entekhaby ra vared konid :";
			setColor(1, 15);
			cin >> choose_hour;
			break;
		}
	}
	show.close();
}
void lab::rezerve(string username) {
	string rezerve_name;
	int rezerve_num;
	string rezerve_kind;
	int rezerve_price;
	string rezerve_date;
	string choose_day;
	string choose_hour;
	string user;
	bool find = true;
	string search_name = lab_name + "rez.txt";
	ifstream showlist(search_name);
	while (showlist >> user) {
		showlist >> rezerve_name;
		showlist >> choose_day;
		showlist >> choose_hour;
		if (this->rezerve_name == rezerve_name)
			if (this->choose_day == choose_day)
				if (this->choose_hour == choose_hour) {
					find = false;
					break;
				}
	}
	if (find == true) {
		ofstream write(search_name, ios::app);
		write << username << " " << this->rezerve_name << " " << this->choose_day << " " << this->choose_hour << " " << name_search << endl;
	}
	else
		cout << "shoma dar in time nemitavinid rezerv konid";
}
void lab::add_lab() {
	ifstream show("lab.txt");
	string name;
	int num;
	int num2 = 0;
	while (show >> num) {
		num2 = num;
		show >> name;
		cout << num << " " << name << endl;
	}
	show.close();
	setColor(2, 15);
	cout << "name azmayeshgah ra vared konid:" << endl;
	setColor(1, 15);
	string name_inter;
	cin >> name_inter;
	ofstream add("lab.txt", ios::app);
	add << num2 + 1 << " " << name_inter << endl;
	setColor(2, 15);
	cout << "sabt shod" << endl;
	setColor(1, 15);
	Sleep(1000);
}
void lab::add_experiment() {
	system("cls");
	ifstream show(search_name);
	string name;
	int num;
	string kind;
	int price;
	string date;
	string hour;
	int num2 = 0;
	while (show >> num) {
		num2 = num;
		show >> name;
		show >> kind;
		show >> price;
		show >> date;
		show >> hour;
	}
	show.close();
	ofstream add(search_name, ios::app);
	int num_inter;
	string name_inter;
	string kind_inter;
	int price_inter;
	string date_inter;
	string hour_inter;
	setColor(2, 15);
	cout << "nam ra vared konid :";
	setColor(1, 15);
	cin >> name_inter;
	setColor(2, 15);
	cout << "noe mohasebe gheimat ra vared konid :";
	setColor(1, 15);
	cin >> kind_inter;
	setColor(2, 15);
	cout << "gheimat ra vared konid :";
	setColor(1, 15);
	cin >> price_inter;
	setColor(2, 15);
	cout << "tarikh estefade re vared konid :";
	setColor(1, 15);
	cin >> date_inter;
	setColor(2, 15);
	cout << "saat estefade re vared konid :";
	setColor(1, 15);
	cin >> hour_inter;
	add << num2 + 1 << " " << name_inter << " " << kind_inter << " " << price_inter << " " << date_inter << " " << hour_inter << endl;

}
void gozaresh::menu() {
	int menu_opt = 1;
	while (menu_opt != 0) {
		system("cls");
		setColor(15, 4);
		cout << "1.moshahede afrad";
		setColor(0, 11);
		cout << "___";
		setColor(15, 4);
		cout << "2.moshahede etebarat";
		setColor(0, 11);
		cout << "___";
		setColor(15, 4);
		cout << "3.moshahede taeed shodeha";
		setColor(0, 11);
		cout << "___";
		setColor(15, 4);
		cout << "4.moshahede taeed nashodeha";
		setColor(0, 11);
		cout << "___";
		setColor(15, 4);
		cout << "5.bazgasht" << endl;
		setColor(1, 15);
		cin >> menu_opt;
		switch (menu_opt)
		{
		case 1: {
			system("cls");
			show_users();
			setColor(2, 15);
			cout << "gaht khorog kelidy bezanid" << endl;
			setColor(1, 15);
			string a;
			cin >> a;
		}
				break;
		case 2: {
			system("cls");
			show_money();
			setColor(2, 15);
			cout << "gaht khorog kelidy bezanid" << endl;
			setColor(1, 15);
			string a;
			cin >> a;
		}
				break;
		case 3: {
			system("cls");
			taedshode();
			setColor(2, 15);
			cout << "gaht khorog kelidy bezanid" << endl;
			setColor(1, 15);
			string a;
			cin >> a;
		}
				break;
		case 4: {
			system("cls");
			taednashode();
			setColor(2, 15);
			cout << "gaht khorog kelidy bezanid" << endl;
			setColor(1, 15);
			string a;
			cin >> a;
		}
		case 5: {
			exit(0);
		}
				break;
		default:
			break;
		}
	}
}
void gozaresh::show_users() {
	ifstream log("user.txt");
	string log_user, log_pass, lab_name;
	int log_type;
	while (log >> log_type) {
		log >> log_user;
		log >> log_pass;
		log >> lab_name;
		if (log_type == 2)
			cout << log_user << " " << log_pass << " masole azmayeshgahe " << lab_name << endl;
		if (log_type == 3)
			cout << log_user << " " << log_pass << " karbar ady " << endl;
	}
}
void gozaresh::show_money() {
	ifstream money("money.txt");
	string name;
	int pool;
	while (money >> name) {
		money >> pool;
		cout << name << " " << pool << endl;
	}
}
void gozaresh::taedshode() {
	ifstream rez("rezerve.txt");
	string name1, obj1, day1, hour1;
	while (rez >> name1) {
		rez >> obj1;
		rez >> day1;
		rez >> hour1;
		cout << " " << obj1 << " " << day1 << " " << hour1 << endl;
	}
}
void gozaresh::taednashode() {
	ifstream rez("taidnashode.txt");
	string name1, obj1, day1, hour1;
	while (rez >> name1) {
		rez >> obj1;
		rez >> day1;
		rez >> hour1;
		cout << " " << obj1 << " " << day1 << " " << hour1 << endl;
	}
}









