#include <iostream>
#include <fstream>
#include<string>
#include "class.h"
#include <Windows.h>
using namespace std;
string username;
class account : public lab {
private:
	string password;
	int type;
public:
	void log_in();
	void menuadmin();
	void menuadmin2();
	void menu_user();
	void del_lab();
	void del_exp();
	void add_seccond_admin();
	void add_user();
};
void account::log_in() {
	system("cls");
	setColor(15, 4);
	cout << "1.vorood";
	setColor(0, 11);
	cout << "___";
	setColor(15, 4);
	cout << "2.sabte nam" << endl;
	setColor(1, 15);
	int s;
	cin >> s;
	if (s == 1) {
		system("cls");
		cout << "username ra vared konid:";
		cin >> username;
		cout << "password ra vared konid:";
		cin >> password;
		ifstream log("user.txt");
		string log_user, log_pass;
		int log_type;
		while (log >> log_type) {
			log >> log_user;
			log >> log_pass;
			log >> lab_name;
			if (log_user == username)
				if (log_pass == password) {
					type = log_type;
					break;
				}
		}
		if (type == 1)
			menuadmin();
		if (type == 2)
			menuadmin2();
		if (type == 3)
			menu_user();
		else {
			setColor(2, 15);
			cout << "etelat sahih nist";
			setColor(1, 15);
		}
	}
	if (s == 2) {
		system("cls");
		add_user();
		account();
	}

}
 void account::add_user() {
	 ofstream add("user.txt", ios::app);
	 ofstream add2("money.txt", ios::app);
	 string name, pass, lab;
	 int type = 3;
	 setColor(2, 15);
	 cout << "username ra vared konid:";
	 setColor(1, 15);
	 cin >> name;
	 setColor(2, 15);
	 cout << "password ra vared konid:";
	 setColor(1, 15);
	 cin >> pass;
	 add << type << " " << name << " " << pass << " " << "user" << endl;
	 int money = 0;
	 add2 << name << " " << money << endl;
	 setColor(2, 15);
	 cout << "hesab shoma sabt shod" << endl;
	 setColor(1, 15);
	 Sleep(1500);
 }
 void account::del_lab() {
	 ifstream show("lab.txt");
	 ofstream stack("stack.txt", ios::trunc);
	 string name;
	 int num;
	 while (show >> num) {
		 show >> name;
		 if (name != lab_name)
			 stack << num << " " << name << endl;
	 }
	 stack.close();
	 ofstream write("lab.txt", ios::trunc);
	 ifstream read("stack.txt");
	 while (read >> num) {
		 read >> name;
		 write << num << " " << name << endl;

	 }
 }
 void account::del_exp() {
	 system("cls");
	 string rezerve_name;
	 int rezerve_num;
	 string rezerve_kind;
	 int rezerve_price;
	 string rezerve_date;
	 string rezerve_hour;
	 int choose;
	 int find;
	 cin >> choose;
	 ifstream show(search_name);
	 while (show >> rezerve_num) {
		 show >> rezerve_name;
		 show >> rezerve_kind;
		 show >> rezerve_price;
		 show >> rezerve_date;
		 show >> rezerve_hour;
		 if (choose == rezerve_num) {
			 find = rezerve_num;
			 break;
		 }
	 }
	 show.close();
	 ifstream show2(search_name);
	 ofstream stack("stack.txt", ios::trunc);
	 string name;
	 int num;
	 string kind;
	 int price;
	 string date;
	 string hour;
	 while (show >> num) {
		 show >> name;
		 show >> kind;
		 show >> price;
		 show >> date;
		 show >> hour;
		 if(num!=find)
		 stack << num << "	" << name << "		" << kind << "		" << price << "	" << date << endl;
	 }
	 show2.close();
	 ofstream write(search_name, ios::trunc);
	 ifstream read("stack.txt");
	 while (show >> num) {
		 read >> name;
		 read >> kind;
		 read >> price;
		 read >> date;
		 read >> hour;
		 write << num << "	" << name << "		" << kind << "		" << price << "	" << date << endl;
	 }
 }
 void account::add_seccond_admin() {
	 ofstream add("user.txt", ios::app);
	 string name, pass, lab;
	 int type = 2;
	 setColor(2, 15);
	 cout << "username ra vared konid:";
	 setColor(1, 15);
	 cin >> name;
	 setColor(2, 15);
	 cout << "password ra vared konid:";
	 setColor(1, 15);
	 cin >> pass;
	 setColor(2, 15);
	 cout << "azmayeshgah ra entekhab konid:"<<endl;
	 setColor(1, 15);
	 showlab();
	 findlab();
	 add << type << " " << name << " " << pass << " " << lab_name << endl;
 }
  void account::menuadmin()  {
	 int menu_opt=1;
	 while (menu_opt != 15) {
		 system("cls");
		 setColor(15, 4);
		 cout << "1.moshade azmayeshgaha";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "2.sabt azmayeshgah";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "3.hazf azmayeshgah va taghizat";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "4.sabt dastgah azmayeshgah";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "5.sabte masool azmayeshgah" ;
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "6.darkhastha";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "7.vorood be onvane masool azmayeshgah" ;
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "8.vorood be onvane karbar ady";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "9.gozaresh giry";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "10.exit" << endl;
		 setColor(1, 15);
		 cin >> menu_opt;
		 switch (menu_opt)
		 {
		 case 1: {
			 system("cls");
			 setColor(15, 4);
			 cout << "1.moshade tazhizat";
			 setColor(0, 11);
			 cout << "___";
			 setColor(15, 4);
			 cout << "2.khoroog"<<endl;
			 setColor(1, 15);
			 showlab();
			 int s;
			 cin >> s;
			 if (s == 1) {
				 setColor(2,15);
				 cout << "shomare azmayeshgah ra vared koinid" << endl;
				 setColor(1, 15);
				 findlab();
				 showexperiment();
				 setColor(2, 15);
				 cout << "gaht khorog kelidy bezanid" << endl;
				 setColor(1, 15);
				 string a;
				 cin >> a;
			 }
		 }
				 break;
		 case 2: {
			 system("cls");
			 add_lab();
		 }
				 break;
		 case 3: {
			 system("cls");
			 setColor(15, 4);
			 cout << "1.hazf azmayeshgah";
			 setColor(0, 11);
			 cout << "___";
			 setColor(15, 4);
			 cout << "2.kazf taghizat";
			 setColor(1, 15);
			 int s;
			 cin >> s;
			 if (s == 1) {
				 showlab();
				 setColor(2, 15);
				 cout << "shomare azmayeshgah ra vared koinid" << endl;
				 setColor(1, 15);
				 findlab();
				 del_lab();
			 }
			 if (s == 2) {
				 showlab();
				 setColor(2, 15);
				 cout << "shomare vasile ra vared koinid" << endl;
				 setColor(1, 15);
				 findlab();
				 showexperiment();
				 del_exp();
			 }
			
		 }
				 break;
		 case 4: {
			 system("cls");
			 showlab();
			 setColor(2, 15);
			 cout << "shomare azmayeshgah ra vared koinid" << endl;
			 setColor(1, 15);
			 findlab();
			 add_experiment();
		 }
				 break;
		 case 5: {
			 system("cls");
			 add_seccond_admin();
		 }
				 break;
		 case 6: {
			 system("cls");
			 setColor(2, 15);
			 cout << "azmayeshgah ra entekhab konid:" << endl;
			 setColor(1, 15);
			 showlab();
			 findlab();
			 search_name = lab_name + "rez.txt";
			 ifstream rezerve(lab::search_name);
			 string name, obj, day, hour, s, labnam;
			 system("cls");
			 setColor(2, 15);
			 cout << "baray taid 1 va baray rad 2 ra vared konid" << endl;
			 setColor(1, 15);
			 while (rezerve >> name) {
				 int choose;
				 rezerve >> obj;
				 rezerve >> day;
				 rezerve >> hour;
				 rezerve >> labnam;
				 cout << name << " " << obj << " " << day << " " << hour << endl;
				 cin >> choose;
				 if (choose == 1) {
					 ofstream add("rezerve.txt", ios::app);
					 add << name << " " << obj << " " << day << " " << hour;
				 }
				 if (choose == 2) {
					 ofstream stack("taidnashode.txt");
					 stack << name << " " << obj << " " << day << " " << hour;
				 }
			 }
			 ofstream rezerv(lab::search_name, ios::trunc);
		 }
			 break;
		 case 7: {
			 system("cls");
			 menuadmin2();
		 }
			 break;
		 case 8: {
			 system("cls");
			 menu_user();

		 }
				 break;
		 case 9: {
			 gozaresh sku;
			 sku.menu();
		 }
				break;
		 case 10:
			exit(0);
		 default:
			 break;
		 }
	 }
 }
 void account::menuadmin2() {
	 int menu_opt=1;
	 while (menu_opt != 0) {
		 system("cls");
		 setColor(15, 4);
		 cout << "1.moshahede tazhizat";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "2.sabt datsgah azmayeshgah";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "3.moshahede darkhast ha";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4); 
		 cout << "4.hazfe tazhizat";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "5.vorood be onvane karbar ady";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "6.exit"<<endl;
		 setColor(1, 15);
		 cin >> menu_opt;
		 switch (menu_opt)
		 {
		 case 1: {
			 system("cls");
			 search_name = lab_name + ".txt";
			 showexperiment();
			 setColor(2, 15);;
			 cout << "gahat khoroog kelidy bezanid" << endl;
			 string s;
			 setColor(1, 15);
			 cin >> s;
		 }
				 break;
		 case 2: {
			 system("cls");
			 search_name = lab_name + ".txt";
			 add_experiment();
		 }
				 break;
		 case 3: {
			 system("cls");
			 search_name = lab_name + "rez.txt";
			 ifstream rezerve(lab::search_name);
			 string name, obj, day, hour, s, labnam;
			 bool find = true;
			 while (rezerve >> name) {
				 find = false;
				 system("cls");
				 setColor(2, 15);
				 cout << "baray taid 1 va baray rad 2 ra vared konid" << endl;
				 setColor(1, 15);
				 int choose;
				 rezerve >> obj;
				 rezerve >> day;
				 rezerve >> hour;
				 rezerve >> labnam;
				 cout << name << " " << obj << " " << day << " " << hour;
				 cin >> choose;
				 if (choose == 1) {
					 ofstream add("rezerve.txt", ios::app);
					 cout << name << " " << obj << " " << day << " " << hour;
				 }
			 }
			 if (find == true) {
				 setColor(2, 15);;
				 cout << "darkhasty mojood nist" << endl;
				 setColor(1, 15);
				 Sleep(1500);
			 }
		 }
				 break;
		 case 4: {
			 showlab();
			 setColor(2, 15);
			 cout << "shomare vasile ra vared koinid" << endl;
			 setColor(1, 15);
			 findlab();
			 showexperiment();
			 del_exp();
		 }
				 break;
		 case 5: {
			 system("cls");
			 menu_user();
		 }
		 case 6:
			 exit(0);
		 default:
			 break;
		 }
	 }
 }
 void account::menu_user() {
	 int menu_opt=1;
	 while (menu_opt != 0) {
		 system("cls");
		 setColor(15, 4);
		 cout << "1.moshahede azmayeshgaha va tazhizat";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "2.sabt darkhast";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "3.moshahede darkhast ha";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "4.etebar";
		 setColor(0, 11);
		 cout << "___";
		 setColor(15, 4);
		 cout << "5.exit"<<endl;
		 setColor(1, 15);
		 cin >> menu_opt;
		 switch (menu_opt)
		 {
		 case 1: {
			 system("cls");
			 setColor(15, 4);
			 cout << "1.moshade tazhizat";
			 setColor(0, 11);
			 cout << "___";
			 setColor(15, 4);
			 cout << "2.khoroog" << endl;
			 setColor(1, 15);
			 showlab();
			 int s;
			 cin >> s;
			 if (s == 1) {
				 setColor(2, 15);
				 cout << "shomare azmayeshgah ra vared koinid" << endl;
				 setColor(1, 15);
				 findlab();
				 showexperiment();
				 setColor(2, 15);
				 cout << "gaht khorog kelidy bezanid" << endl;
				 setColor(1, 15);
				 string a;
				 cin >> a;
			 }
		 }
			 break;
		 case 2: {
			 system("cls");
			 showlab();
			 findlab();
			 showexperiment();
			 choose_experiment();
			 rezerve(username);	 
		 }
				 break;
		 case 3: {
			 system("cls");
			 string s = "lab.txt";
			 ifstream show1(s);
			 string nam;
			 int num;
			 while (show1 >> num) {
				 show1 >> nam;
				 search_name = nam + "rez.txt";
				 ifstream rezerve(lab::search_name);
				 string name, obj, day, hour;
				 while (rezerve >> name) {
					 rezerve >> obj;
					 rezerve >> day;
					 rezerve >> hour;
					 if (username == name) {
						 cout << obj << " " << day << " " << hour << " ";
						 setColor(6, 15);
						 cout << "dar daste barresy" << endl;
						 setColor(1, 15);

					 }
				 }
			 }
			 ifstream rez("rezerve.txt");
			 string name1, obj1, day1, hour1;
			 while (rez >> name1) {
				 rez >> obj1;
				 rez >> day1;
				 rez >> hour1;
				 if (username == name1) {
					 cout  << " " << obj1 << " " << day1 << " " << hour1 << " ";
					 setColor(2, 15);
					 cout << "taid shode" << endl;
					 setColor(1, 15);
				 }
			 }
			 ifstream noot("taidnashode.txt");
			 string name2, obj2, day2, hour2;
			 while (noot >> name2) {
				 noot >> obj2;
				 noot >> day2;
				 noot >> hour2;
				 if (username == name2) {
					 cout  << " " << obj2 << " " << day2 << " " << hour2 << " ";
					 setColor(4, 15);
					 cout << "taid nashode" << endl;
					 setColor(1, 15);

				 }
			 }
			 setColor(6, 15);
			 cout <<endl<< "gaht khorog kelidy bezanid" << endl;
			 setColor(1, 15);
			 string a;
			 cin >> a;
		 }
				 break;
		 case 4: {
			 ifstream pool("money.txt");
			 string name;
			 int num;
			 while (pool >> name) {
				 pool >> num;
				 if (username == name) {
					 cout << "etebar shoma barabar ast ba:" << num << endl;
					 break;
				 }
			 }
			 pool.close();
			 setColor(2, 15);
			 cout << "baraye khoroog 1 va baray efzayesh 2 ra vared konid:" << endl;
			 setColor(1, 15);
			 int s;
			 cin >> s;
			 
			 if (s == 1) {
				 break;
			 }
			 if (s == 2) {
				 setColor(2, 15);
				 cout << "mabkag ra vared konid:" << endl;
				 int m;
				 cin >> m;
				 setColor(1, 15);
				 ifstream pool2("money.txt");
				 ofstream stack("stack.txt", ios::trunc);
				 while (pool2 >> name) {
						pool2 >> num;
					 if (username == name) 
						 stack << name<<" "<< m << endl;
					 else
						 stack << name << " " << num << endl;
				 }
				 ofstream write("money.txt", ios::trunc);
				 ifstream read("stack.txt");
				 while (read >> name) {
						read >> num;
						write << name << " " << num << endl;
				 }
			 }
		 }
		 case 5:
			 exit(0);
			 break;
		 default:
			 break;
		 }
	 }
 }

int main(){
	system("color f0");
	setColor(1, 15);
	account sku;
	sku.log_in();
	return 0;
}
